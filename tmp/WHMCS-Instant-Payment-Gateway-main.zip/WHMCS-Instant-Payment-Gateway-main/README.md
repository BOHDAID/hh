# Instant Payment Gateway WHMCS
Instant WHMCS payment gateway to accept credit or debit cards or Google Pay or Apple Pay. Instant payouts to USDC wallet.

# Install Guide

* Upload files via FTP to modules/gateways
* Activate the desired payment gateway from your WHMCS admin
* Insert your USDC (Polygon) wallet address to receive instant payouts.
